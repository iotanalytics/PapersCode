This package implements the synchrosqueezed wave packet and synchrosqueezed curve let transform developed in the following papers. 

[1] H. Yang and L. Ying. Synchrosqueezed wave packet transform for 2d mode decompo- sition. SIAM Journal on Imaging Sciences, 6(4):1979–2009, 2013.[2] H. Yang and L. Ying. Synchrosqueezed curvelet transform for two-dimensional mode decomposition. SIAM Journal on Mathematical Analysis, 46(3):2052–2083, 2014.

If you have further questions, please contact Haizhao Yang at haizhao@stanford.edu.

